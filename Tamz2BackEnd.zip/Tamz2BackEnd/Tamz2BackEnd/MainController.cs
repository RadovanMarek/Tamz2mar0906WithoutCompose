using Azure.Core;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Tamz2BackEnd.ApiModels;
using Tamz2BackEnd.ApiModels.NewFolder;
using Tamz2BackEnd.ApiModels.ResponseModels;
using Tamz2BackEnd.Services;

namespace Tamz2BackEnd
{
    public class MainController
    {
        private readonly ILogger<MainController> _logger;
        private readonly IProcessRequestsService _processRequestsService;

        public MainController(ILogger<MainController> logger, IProcessRequestsService processRequestsService)
        {
            _logger = logger;
            _processRequestsService = processRequestsService;
        }

        [Function("login")]
        public async Task<IActionResult> Login([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            string requestBody;
            using (StreamReader streamReader = new StreamReader(req.Body))
            {
                requestBody = await streamReader.ReadToEndAsync();
            }

            var request = JsonConvert.DeserializeObject<LoginApi>(requestBody);

            if (request != null)
            {
                try
                {
                    if(!await _processRequestsService.Login(request))
                    {
                        return new OkObjectResult(new GeneralResponseModel()
                        {
                            Message = "Invalid password or username",
                            Success = false
                        });
                    }

                    return new OkObjectResult(new GeneralResponseModel()
                    {
                        Message = "Sucessful login",
                        Success = true
                    });
                }catch(Exception ex)
                {
                    return new BadRequestObjectResult(new GeneralResponseModel()
                    {
                        Message = $"Exception occured: {ex.Message}",
                        Success = false
                    });
                }
            }

            return new BadRequestObjectResult(new GeneralResponseModel()
            {
                Message = "Invalid body",
                Success = false
            });
        }

        [Function("register")]
        public async Task<IActionResult> Register([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            string requestBody;
            using (StreamReader streamReader = new StreamReader(req.Body))
            {
                requestBody = await streamReader.ReadToEndAsync();
            }

            var request = JsonConvert.DeserializeObject<RegisterApi>(requestBody);

            if (request != null)
            {
                try
                {
                    if (!await _processRequestsService.Register(request))
                    {
                        return new OkObjectResult(new GeneralResponseModel()
                        {
                            Message = "Username taken",
                            Success = false
                        });
                    }

                    return new OkObjectResult(new GeneralResponseModel()
                    {
                        Message = "Registration sucsefully",
                        Success = true
                    });
                }
                catch (Exception ex)
                {
                    return new BadRequestObjectResult(new GeneralResponseModel()
                    {
                        Message = $"Exception occured: {ex.Message}",
                        Success = false
                    });
                }
            }

            return new BadRequestObjectResult(new GeneralResponseModel()
            {
                Message = $"Invalid request payload",
                Success = false
            });
        }

        [Function("getUserDatas")]
        public async Task<IActionResult> GetUserDatas([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            string requestBody;
            using (StreamReader streamReader = new StreamReader(req.Body))
            {
                requestBody = await streamReader.ReadToEndAsync();
            }

            var request = JsonConvert.DeserializeObject<List<string>?>(requestBody);

            if (request != null)
            {
                try
                {
                    var result = await _processRequestsService.GetUserDatas(request);
                    return new OkObjectResult(new UserInfosResponse()
                    {
                        Users = result ?? new List<UserResponseModel>(),
                        Success = true
                    });
                }
                catch (Exception ex)
                {
                    return new BadRequestObjectResult(new UserInfosResponse()
                    {
                        Users = new List<UserResponseModel>(),
                        Message = $"Exception occured: {ex.Message}",
                        Success = false
                    });
                }
            }

            return new BadRequestObjectResult(new UserInfosResponse()
            {
                Users = new List<UserResponseModel>(),
                Message = $"Invalid request payload",
                Success = false
            });
        }

        [Function("createGroup")]
        public async Task<IActionResult> CreateGroup([HttpTrigger(AuthorizationLevel.Function, "put")] HttpRequest req)
        {
            var groupName = req.Query["group_name"];
            var creator = req.Query["creator_login_name"];

            try
            {
                await _processRequestsService.InsertNewGroup(groupName, creator);
                return new OkObjectResult(new GeneralResponseModel()
                {
                    Success = true,
                    Message = "Group created sucessfuly"
                });
            }catch (Exception ex)
            {
                return new BadRequestObjectResult(new GeneralResponseModel()
                {
                    Message = $"Error occured {ex.Message}",
                    Success = false
                });
            }
            
        }

        [Function("getGroupsWithUsers")]
        public async Task<IActionResult> GetGroupsForUser([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest req)
        {
            var login = req.Query["login"];

            try
            {
                var result = await _processRequestsService.GetGroupsByLoginWithUsers(login);
                return new OkObjectResult(new GroupResponse()
                {
                    Groups = result,
                    Success = true,
                });
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(new GroupResponse()
                {
                    Message = $"Error occured {ex.Message}",
                    Success = false
                });
            }

        }

        [Function("getUsersByLoginLike")]
        public async Task<IActionResult> GetUsersByName([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest req)
        {
            var login = req.Query["login"];

            try
            {
                var result = await _processRequestsService.GetUserLikeLogin(login);
                return new OkObjectResult(new UserInfosResponse()
                {
                    Users = result ?? new List<UserResponseModel>(),
                    Success = true
                });
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(new UserInfosResponse()
                {
                    Users = new List<UserResponseModel>(),
                    Message = $"Exception occured: {ex.Message}",
                    Success = false
                });
            }           
        }

        [Function("getEventsByGroup")]
        public async Task<IActionResult> GetEvents([HttpTrigger(AuthorizationLevel.Function, "get")] HttpRequest req)
        {
            var groupId = req.Query["group_id"];

            try
            {
                var result = await _processRequestsService.GetEvents(int.Parse(groupId));
                return new OkObjectResult(new EventResponse()
                {
                    Events = result ?? new List<EventResponseModel>(),
                    Success = true
                });
            }
            catch (Exception ex)
            {
                return new BadRequestObjectResult(new EventResponse()
                {
                    Events = new List<EventResponseModel>(),
                    Message = $"Exception occured: {ex.Message}",
                    Success = false
                });
            }
        }

        [Function("insertUserToGroup")]
        public async Task<IActionResult> InsertUserToGroup([HttpTrigger(AuthorizationLevel.Function, "put")] HttpRequest req)
        {
            var groupId = req.Query["group_id"];
            var userId = req.Query["user_id"];

            try
            {
                await _processRequestsService.InsertUserToGroup(int.Parse(groupId), int.Parse(userId));
                return new OkObjectResult(new GeneralResponseModel(){
                    Success = true,
                });
            }
            catch (Exception ex)
            {
                return new OkObjectResult(new GeneralResponseModel()
                {
                    Success = false,
                });
            }
        }

        [Function("insertEvent")]
        public async Task<IActionResult> InsertEvent([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            string requestBody;
            using (StreamReader streamReader = new StreamReader(req.Body))
            {
                requestBody = await streamReader.ReadToEndAsync();
            }

            var request = JsonConvert.DeserializeObject<EventApi>(requestBody);

            if (request != null)
            {
                try
                {
                    await _processRequestsService.InsertNewEvent(request);
                    return new OkObjectResult(new GeneralResponseModel()
                    {
                        Success = true
                    });
                }
                catch (Exception ex)
                {
                    return new BadRequestObjectResult(new GeneralResponseModel()
                    {
                        Message = $"Exception occured: {ex.Message}",
                        Success = false
                    });
                }
            }

            return new BadRequestObjectResult(new GeneralResponseModel()
            {
                Message = $"Invalid request payload",
                Success = false
            });
        }

        [Function("updateEvent")]
        public async Task<IActionResult> UpdateEvent([HttpTrigger(AuthorizationLevel.Function, "post")] HttpRequest req)
        {
            string requestBody;
            using (StreamReader streamReader = new StreamReader(req.Body))
            {
                requestBody = await streamReader.ReadToEndAsync();
            }

            var request = JsonConvert.DeserializeObject<EventApi>(requestBody);

            if (request != null)
            {
                try
                {
                    await _processRequestsService.UpdateAnEvent(request);
                    return new OkObjectResult(new GeneralResponseModel()
                    {
                        Success = true
                    });
                }
                catch (Exception ex)
                {
                    return new BadRequestObjectResult(new GeneralResponseModel()
                    {
                        Message = $"Exception occured: {ex.Message}",
                        Success = false
                    });
                }
            }

            return new BadRequestObjectResult(new GeneralResponseModel()
            {
                Message = $"Invalid request payload",
                Success = false
            });
        }
    }
}
