﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.ApiModels.NewFolder
{
    public class UserResponseModel
    {
        [JsonProperty("id")]
        public int Id { get; set; }
        [JsonProperty("loginName")]
        public string LoginName { get; set; }
        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }
        [JsonProperty("gender")]
        public string Gender { get; set; }
        [JsonProperty("photo")]
        public string? Photo { get; set; }
    }
}
