﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.ApiModels.NewFolder
{
    public class UserInfosResponse : GeneralResponseModel
    {
        [JsonProperty("users")]
        public List<UserResponseModel> Users { get; set; }
    }
}
