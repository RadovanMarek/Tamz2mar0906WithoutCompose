﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.ApiModels.NewFolder;

namespace Tamz2BackEnd.ApiModels.ResponseModels
{
    public class EventResponse : GeneralResponseModel
    {
        public List<EventResponseModel> Events { get; set; }
    }
}
