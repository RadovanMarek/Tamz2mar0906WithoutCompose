﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.ApiModels.ResponseModels
{
    public class EventResponseModel
    {
        public int GroupId { get; set; }
        public int CreatorId { get; set; }
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; }
        public int AcommodationProvided { get; set; }
        public string Description { get; set; }
    }
}
