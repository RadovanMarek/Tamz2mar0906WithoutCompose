﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.DtoModels;

namespace Tamz2BackEnd.ApiModels.NewFolder
{
    public class GroupResponse : GeneralResponseModel
    {
        public List<GroupResponseModel> Groups { get; set; }
    }
}
