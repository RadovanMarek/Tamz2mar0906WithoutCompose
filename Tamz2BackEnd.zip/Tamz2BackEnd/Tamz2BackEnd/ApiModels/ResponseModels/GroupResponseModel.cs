﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.ApiModels.NewFolder
{
    public class GroupResponseModel
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public string GroupCreator { get; set; }
        public List<UserResponseModel> Users { get; set; } = new List<UserResponseModel>();
    }
}
