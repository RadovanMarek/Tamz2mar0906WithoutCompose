﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.ApiModels
{
    public class RegisterApi
    {
        [JsonProperty("loginName")]
        public string LoginName { get; set; }
        [JsonProperty("password")]
        public string Password { get; set; }
        [JsonProperty("phoneNumber")]
        public string PhoneNumber { get; set; }
        [JsonProperty("gender")]
        public string Gender { get; set; }
        [JsonProperty("photo")]
        public string? Photo { get; set; }
    }
}
