﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Services;

namespace Tamz2BackEnd.Repositories
{
    public interface IUserRepository
    {
        Task<UserDto?> GetUserByLogin(string login);
        Task InsertUser(UserDto userDto);
        Task<List<UserDto>> GetUserByLoginLike(string login);
    }
    public class UserRepository : BaseRepository<UserDto>, IUserRepository
    {
        public UserRepository(TamzDbContext context) : base(context)
        {
        }

        public async Task<List<UserDto>> GetUserByLoginLike(string login)
        {
            var result = await FindAsync(x => x.LoginName.Contains(login));
            return result.Take(5).ToList();
        }

        public async Task<UserDto?> GetUserByLogin(string login)
        {
            var result = await FindAsync(x => x.LoginName == login);
            return result.FirstOrDefault();
        }

        public async Task InsertUser(UserDto userDto)
        {
            await AddAsync(userDto);
            await SaveChangesAsync();
        }
    }
}
