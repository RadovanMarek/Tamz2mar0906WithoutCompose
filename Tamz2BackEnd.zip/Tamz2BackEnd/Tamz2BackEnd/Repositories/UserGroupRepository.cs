﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Services;

namespace Tamz2BackEnd.Repositories
{
    public interface IUserGroupRepository
    {
        Task InsertNewUserGroup(int groupId, int userId);
    }
    public class UserGroupRepository : BaseRepository<GroupUserDto>, IUserGroupRepository
    {
        public UserGroupRepository(TamzDbContext context) : base(context)
        {
        }

        public async Task InsertNewUserGroup(int groupId, int userId)
        {
            await AddAsync(new GroupUserDto
            {
                GroupId = groupId,
                UserId = userId
            });
            await SaveChangesAsync();
        }
    }
}
