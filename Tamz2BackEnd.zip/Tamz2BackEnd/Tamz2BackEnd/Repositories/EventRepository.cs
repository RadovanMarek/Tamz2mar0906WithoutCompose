﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Services;

namespace Tamz2BackEnd.Repositories
{
    public interface IEventRepository
    {
        Task<List<EventDto>> GetGroupEvents(int groupId);
        Task InsertNewEvent(EventDto eventDto);
        Task UpdateEvent(EventDto eventDto);
    }
    public class EventRepository : BaseRepository<EventDto>, IEventRepository
    {
        public EventRepository(TamzDbContext context) : base(context)
        {
        }

        public async Task<List<EventDto>> GetGroupEvents(int groupId)
        {
            var result = await FindAsync(x => x.GroupId == groupId);
            return result.ToList();
        }

        public async Task InsertNewEvent(EventDto eventDto)
        {
            await AddAsync(eventDto);
            await SaveChangesAsync();
        }

        public async Task UpdateEvent(EventDto eventDto)
        {
            Update(eventDto);
            await SaveChangesAsync();
        }
    }
}
