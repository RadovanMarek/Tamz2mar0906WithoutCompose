﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Services;

namespace Tamz2BackEnd.Repositories
{
    public interface IGroupRepository
    {
        Task InsertNewGroup(string groupName, string creatorName);
        Task<GroupDto?> GetGroup(string groupName);
        Task<List<GroupDto>> GetGroupsByLoginWithUsers(string loginName);
        Task<GroupDto?> GetGroupByCreator(string groupName, string creator);
    }
    public class GroupRepository : BaseRepository<GroupDto>, IGroupRepository
    {
        public GroupRepository(TamzDbContext context) : base(context)
        {
        }

        public async Task InsertNewGroup(string groupName, string creatorName)
        {
            await AddAsync(new GroupDto
            {
                GroupName = groupName,
                GroupCreator = creatorName
            });
            await SaveChangesAsync();
        }

        public async Task<List<GroupDto>> GetGroupsByLoginWithUsers(string loginName)
        {
            var query = _dbSet
                .Include(x => x.GroupUsers)   
                .ThenInclude(y => y.User);          

            var result = await query
                .Where(x => x.GroupUsers.Any(y => y.User.LoginName == loginName))
                .ToListAsync();

            return result;
        }

        public async Task<GroupDto?> GetGroup(string groupName)
        {
            var result = await FindAsync(x => x.GroupName == groupName);
            return result.FirstOrDefault();
        }

        public async Task<GroupDto?> GetGroupByCreator(string groupName, string creator)
        {
            var result = await FindAsync(x => x.GroupName == groupName && x.GroupCreator == creator);
            return result.OrderByDescending(x => x.Id).FirstOrDefault();
        }
    }
}
