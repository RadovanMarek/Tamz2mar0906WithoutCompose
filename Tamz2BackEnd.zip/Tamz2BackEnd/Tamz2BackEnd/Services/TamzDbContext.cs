﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Tamz2BackEnd.DtoModels;


namespace Tamz2BackEnd.Services
{

    public class TamzDbContext : DbContext
    {
        public DbSet<UserDto> Users { get; set; }
        public DbSet<GroupDto> Groups { get; set; }
        public DbSet<GroupUserDto> GroupUsers { get; set; }
        public DbSet<EventDto> Events { get; set; }

        public TamzDbContext(DbContextOptions<TamzDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UserDto>(entity =>
            {
                entity.ToTable("Users");
                entity.HasKey(u => u.Id);

                entity.Property(u => u.LoginName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(u => u.Password)
                    .IsRequired()
                    .HasMaxLength(70);

                entity.Property(u => u.PhoneNumber)
                    .IsRequired()
                    .HasMaxLength(13);

                entity.Property(u => u.Gender)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<GroupDto>(entity =>
            {
                entity.ToTable("Groups");
                entity.HasKey(g => g.Id);

                entity.Property(g => g.GroupName)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<GroupUserDto>(entity =>
            {
                entity.ToTable("GroupsUsers");
                entity.HasKey(gu => gu.Id);

                entity.HasOne(gu => gu.Group)
                    .WithMany(g => g.GroupUsers)
                    .HasForeignKey(gu => gu.GroupId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(gu => gu.User)
                    .WithMany(u => u.GroupUsers)
                    .HasForeignKey(gu => gu.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<EventDto>(entity =>
            {
                entity.ToTable("Events");
                entity.HasKey(e => e.Id);

                entity.Property(e => e.EventName)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.EventDate)
                    .IsRequired();

                entity.Property(e => e.Location)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.AccommodationProvided)
                    .IsRequired();

                entity.Property(e => e.Description)
                    .HasMaxLength(1000);

                entity.HasOne(e => e.Group)
                    .WithMany()
                    .HasForeignKey(e => e.GroupId)
                    .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.Creator)
                    .WithMany() 
                    .HasForeignKey(e => e.CreatorId)
                    .OnDelete(DeleteBehavior.Cascade);
            });
        }
    }
}