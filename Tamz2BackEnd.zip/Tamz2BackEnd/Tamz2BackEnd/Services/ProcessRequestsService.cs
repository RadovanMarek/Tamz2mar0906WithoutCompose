﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tamz2BackEnd.ApiModels;
using Tamz2BackEnd.ApiModels.NewFolder;
using Tamz2BackEnd.ApiModels.ResponseModels;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Helpers;
using Tamz2BackEnd.Repositories;

namespace Tamz2BackEnd.Services
{
    public interface IProcessRequestsService
    {
        Task<bool> Register(RegisterApi registerApi);
        Task<bool> Login(LoginApi loginApi);
        Task<List<UserResponseModel>> GetUserDatas(List<string> userNames);
        Task InsertNewGroup(string groupName, string loginName);
        Task<List<GroupResponseModel>> GetGroupsByLoginWithUsers(string loginName);
        Task<List<UserResponseModel>> GetUserLikeLogin(string prompt);

        Task InsertUserToGroup(int groupId, int userId);

        Task InsertNewEvent(EventApi eventApi);
        Task UpdateAnEvent(EventApi eventApi);
        Task<List<EventResponseModel>> GetEvents(int groupId);
    }
    public class ProcessRequestsService(
        IUserRepository userRepository, 
        IGroupRepository groupRepository, 
        IUserGroupRepository userGroupRepository,
        IEventRepository eventRepository) : IProcessRequestsService
    {
        public async Task<bool> Login(LoginApi loginApi)
        {
            loginApi.Password = Sha256Helper.ComputeHash(loginApi.Password);
            var user = await userRepository.GetUserByLogin(loginApi.LoginName);
            if(user == null)
            {
                return false;
            }
            else
            {
                if(user.Password == loginApi.Password)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public async Task<bool> Register(RegisterApi registerApi)
        {
            registerApi.Password = Sha256Helper.ComputeHash(registerApi.Password);

            var user = await userRepository.GetUserByLogin(registerApi.LoginName);
            if (user == null)
            {
                await userRepository.InsertUser(Mapper.Map(registerApi));
                return true;
            }
            else
            {
                return false;
            }

        }

        public async Task<List<UserResponseModel>> GetUserDatas(List<string> userNames)
        {
            var result = new List<UserResponseModel>();
            foreach(var userName in userNames)
            {
                var user = await userRepository.GetUserByLogin(userName);
                user.Password = string.Empty;
                if (user != null)
                    result.Add(Mapper.Map(user));
            }

            return result;
        }

        public async Task InsertNewGroup(string groupName, string loginName)
        {
            await groupRepository.InsertNewGroup(groupName, loginName);

            var group = await groupRepository.GetGroupByCreator(groupName,loginName);
            var login = await userRepository.GetUserByLogin(loginName);

            await userGroupRepository.InsertNewUserGroup(group.Id, login.Id);
        }

        public async Task<List<GroupResponseModel>> GetGroupsByLoginWithUsers(string loginName)
        {
            var dbResult = await groupRepository.GetGroupsByLoginWithUsers(loginName);
            List<GroupResponseModel> groupResponseModel = new List<GroupResponseModel>();   

            foreach (var result in dbResult)
            {
                groupResponseModel.Add(Mapper.Map(result, result.GroupUsers.Select(x => x.User).ToList()));
            }

            return groupResponseModel;
        }

        public async Task<List<UserResponseModel>> GetUserLikeLogin(string prompt)
        {
            var result = new List<UserResponseModel>();

            var users = await userRepository.GetUserByLoginLike(prompt);

            foreach(var user in users) { 
                result.Add(Mapper.Map(user));           
            }

            return result;
        }

        public async Task InsertUserToGroup(int groupId, int userId)
        {
            try
            {
                await userGroupRepository.InsertNewUserGroup(groupId,userId);
            }catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task InsertNewEvent(EventApi eventApi)
        {
            try
            {
                await eventRepository.UpdateEvent(Mapper.Map(eventApi));
            }catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task UpdateAnEvent(EventApi eventApi)
        {
            try
            {
                await eventRepository.UpdateEvent(Mapper.Map(eventApi));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public async Task<List<EventResponseModel>> GetEvents(int groupId)
        {
            var eventDto = await eventRepository.GetGroupEvents(groupId);
            List<EventResponseModel> result = new();

            foreach(var eventD in eventDto)
            {
                result.Add(Mapper.MapEventResponse(eventD));
            }
            return result;
        }
    }
}
