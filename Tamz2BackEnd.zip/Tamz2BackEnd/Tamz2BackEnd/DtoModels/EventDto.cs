﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.DtoModels
{
    public class EventDto
    {
        public int Id { get; set; }
        public int GroupId { get; set; }
        public int CreatorId { get; set; }
        public string EventName { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; }
        public bool AccommodationProvided { get; set; }
        public string? Description { get; set; }
        public GroupDto Group { get; set; }
        public UserDto Creator { get; set; }
    }

}
