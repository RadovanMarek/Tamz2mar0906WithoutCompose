﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.DtoModels
{
    public class GroupDto
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
        public string GroupCreator {  get; set; }
        public ICollection<GroupUserDto> GroupUsers { get; set; } = new List<GroupUserDto>();
    }
}
