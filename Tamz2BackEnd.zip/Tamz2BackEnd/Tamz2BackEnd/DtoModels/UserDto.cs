﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamz2BackEnd.DtoModels
{
    public class UserDto
    {
        public int Id { get; set; }
        public string LoginName { get; set; }
        public string Password { get; set; }
        public string PhoneNumber { get; set; }
        public byte[]? Photo { get; set; }
        public string Gender { get; set; }
        public ICollection<GroupUserDto> GroupUsers { get; set; } = new List<GroupUserDto>();
    }
}
