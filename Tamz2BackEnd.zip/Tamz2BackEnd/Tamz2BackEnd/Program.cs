using Microsoft.Azure.Functions.Worker;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Tamz2BackEnd.DtoModels;
using Tamz2BackEnd.Repositories;
using Tamz2BackEnd.Services;
using static Microsoft.ApplicationInsights.MetricDimensionNames.TelemetryContext;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices((context,services) =>
    {
        var configuration = context.Configuration;

        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        services.AddScoped<IProcessRequestsService, ProcessRequestsService>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IUserGroupRepository, UserGroupRepository>();
        services.AddScoped<IGroupRepository, GroupRepository>();
        services.AddScoped<IEventRepository, EventRepository>();

        var connectionString = configuration.GetValue<string>("connection_string");


        services.AddDbContext<TamzDbContext>(
            dbContextOptions => dbContextOptions
                .UseSqlServer(connectionString)
        );
    })
    .Build();

host.Run();
