﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Tamz2BackEnd.ApiModels;
using Tamz2BackEnd.ApiModels.NewFolder;
using Tamz2BackEnd.ApiModels.ResponseModels;
using Tamz2BackEnd.DtoModels;

namespace Tamz2BackEnd.Helpers
{
    public static class Mapper
    {
        public static UserDto Map(RegisterApi registerApi)
        {
            return new UserDto()
            {
                LoginName = registerApi.LoginName,
                Password = registerApi.Password,
                PhoneNumber = registerApi.PhoneNumber,
                Gender = registerApi.Gender,
                Photo = Convert.FromBase64String(registerApi.Photo ?? string.Empty)
            };
        }

        public static UserResponseModel Map(UserDto userDto)
        {
            return new UserResponseModel()
            {
                Id = userDto.Id,
                LoginName = userDto.LoginName,
                PhoneNumber = userDto.PhoneNumber,
                Gender = userDto.Gender,
                Photo = userDto.Photo != null && userDto.Photo.Length > 0
                    ? Convert.ToBase64String(userDto.Photo)
                    : string.Empty
            };
        }

        public static GroupResponseModel Map(GroupDto groupDto, List<UserDto> userDtos)
        {
            GroupResponseModel groupResponseModel = new GroupResponseModel()
            {
                Id = groupDto.Id,
                GroupName = groupDto.GroupName,
                GroupCreator = groupDto.GroupCreator,
                Users = new List<UserResponseModel>()
            };

            foreach(UserDto userDto in userDtos)
            {
                groupResponseModel.Users.Add(Map(userDto));
            }

            return groupResponseModel;
        }

        public static EventDto Map(EventApi eventApi)
        {
            return new EventDto()
            {
                CreatorId = eventApi.CreatorId,
                GroupId = eventApi.GroupId,
                Description = eventApi.Description,
                EventDate = eventApi.EventDate,
                AccommodationProvided = eventApi.AcommodationProvided == 1 ? true : false,
                EventName = eventApi.EventName,
                Location = eventApi.Location
            };
        }

        public static EventApi Map(EventDto eventDto)
        {
            return new EventApi()
            {
                CreatorId = eventDto.CreatorId,
                GroupId = eventDto.GroupId,
                Description = eventDto.Description,
                EventDate = eventDto.EventDate,
                AcommodationProvided = eventDto.AccommodationProvided == true ? 1 : 0,
                EventName = eventDto.EventName,
                Location = eventDto.Location
            };
        }

        public static EventResponseModel MapEventResponse(EventDto eventDto)
        {
            return new EventResponseModel()
            {
                CreatorId = eventDto.CreatorId,
                GroupId = eventDto.GroupId,
                Description = eventDto.Description,
                EventDate = eventDto.EventDate,
                AcommodationProvided = eventDto.AccommodationProvided == true ? 1 : 0,
                EventName = eventDto.EventName,
                Location = eventDto.Location
            };
        }
    }
}
    